package com.example.calificaciones;

// Dayana Cruz Ramos

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editTextPrimerParcial = findViewById(R.id.editTextPrimerParcial);
        final EditText editTextSegundoParcial = findViewById(R.id.editTextSegundoParcial);
        Button buttonCalcularPromedio = findViewById(R.id.buttonCalcularPromedio);
        final TextView textViewPromedio = findViewById(R.id.textViewPromedio);

        buttonCalcularPromedio.setOnClickListener(v -> {
            // Obtén las calificaciones ingresadas
            String strPrimerParcial = editTextPrimerParcial.getText().toString();
            String strSegundoParcial = editTextSegundoParcial.getText().toString();

            // Convierte las calificaciones a números
            double primerParcial = Double.parseDouble(strPrimerParcial);
            double segundoParcial = Double.parseDouble(strSegundoParcial);
            // Calcula el promedio
            double promedio = (primerParcial + segundoParcial) / 2;
            // Muestra el promedio en el TextView
            textViewPromedio.setText("Promedio: " + promedio);
        });
    }
}
